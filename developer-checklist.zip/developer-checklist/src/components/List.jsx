export default function List() {
    return (
        <div>
            list
        </div>
    )
}