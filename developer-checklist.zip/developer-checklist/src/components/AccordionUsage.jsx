import * as React from 'react';
import Accordion from '@mui/material/Accordion';
import AccordionSummary from '@mui/material/AccordionSummary';
import AccordionDetails from '@mui/material/AccordionDetails';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';

export default function AccordionUsage(props) {
  const { items } = props;

  // If items are empty or not passed correctly
  if (!items || !Array.isArray(items) || items.length === 0) {
    return <p>No items available</p>;
  }

  return (
    <div>
      {items.map((item, itemIndex) => (
        <Accordion key={itemIndex} className='mb-2 border-none shadow-none bg-item rounded-4'>
          <AccordionSummary
            expandIcon={<ExpandMoreIcon />}
            aria-controls={`panel${itemIndex}-content`}
            id={`panel${itemIndex}-header`}
            className='fs-5'
          >
            {item.name}
          </AccordionSummary>
          <AccordionDetails>
            {item.descriptions.map((description, descIndex) => (
              <div className='d-flex justify-content-between align-items-center accordion-detail p-3 rounded-4 mb-2'>
                <form>
                  <input id='' type="radio" />
                </form>
                <label for='' key={descIndex} className='w-100 ms-3 mb-0'>
                {description}
                </label>
              </div>
            ))}
          </AccordionDetails>
        </Accordion>
      ))}
    </div>
  );
}